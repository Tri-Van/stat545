# createRpackage 0.0.0.9000

* Package can square

# createRpackage 0.0.0.9000

* Added a `NEWS.md` file to track changes to the package.


